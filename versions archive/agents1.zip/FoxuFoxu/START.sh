cd ./server
chmod +x ./AutoStarter.sh
source ./AutoStarter.sh
