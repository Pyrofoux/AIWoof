from .base import *

class VILLAGER(Base):

    def __init__(tracker, diary):
        self.tracker = tracker
        self.diary = diary
